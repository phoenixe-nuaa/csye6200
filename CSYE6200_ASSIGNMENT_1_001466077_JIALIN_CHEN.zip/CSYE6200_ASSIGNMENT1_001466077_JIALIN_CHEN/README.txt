## CSYE 6200 ASSIGNMENT 1
## Author by Jialin Chen

File Description:
Assign1_sample.java          (Provided sample)
Assign1.java                 (main code for Assignment #1)
Student.java                 (Student class to pass student data set)
ScatterPlot.java             (ScatterPlot class(First version) to print 2D-Map)
ScatterPlot2.java            (ScatterPlot2 class(Optimized version) to print 2D-Map)
ScatterPlotExample_Rf.java   (Reference #1 for ScatterPlot)
ScatterPlot_Rf.java          (Reference #2 for ScatterPlot)
PrintMap.java                (Reference #3 for XYPlot)

Instruction:
Please find all the files under the pakcage(CSYE6200Assign1).
Please check the if referenced libraries(ie. jfreeChart for this assignment) has been installed before running.
Link: https://www.tutorialspoint.com/jfreechart/jfreechart_installation.html