/**
 * 
 */
package edu.neu.csye6200.bg;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Observable;

/** class BGGenerationSet: stores each generation of the plant
 * @author Chen.JL
 * 
*/
public class BGGenerationSetDynamic extends Observable implements Runnable {
	
	// Attributes of the GenerationSet
	private Integer number;
	private Double radians;
	private Integer rule;
	
	// BGRuleDynamic and BGGeneration instance
	private BGGeneration bg;
	private BGRuleDynamic br;
	
	// button control flag
	private boolean runflag = true;
	private boolean pauseflag = false;	
	
	
	// Constructor
	public BGGenerationSetDynamic(Integer number, Double radians, Integer rule) {
		// initialize
		this.number = number;
		this.radians = radians;
		this.rule = rule;
	}
	
	
	// Getters and setters
	public Integer getNumber() {
		return number;
	}

	
	public void setNumber(Integer number) {
		this.number = number;
	}
	
	
	public Double getRadians() {
		return radians;
	}

	
	public void setRadians(Double radians) {
		this.radians = radians;
	}
	

	public Integer getRule() {
		return rule;
	}


	public void setRule(Integer rule) {
		this.rule = rule;
	}


	public boolean isRunflag() {
		return runflag;
	}


	public void setRunflag(boolean runflag) {
		this.runflag = runflag;
	}


	public boolean isPauseflag() {
		return pauseflag;
	}
	
	
	public void setPauseflag(boolean value) {
		pauseflag = value;
	}
	
	public void invert() {
		pauseflag = !pauseflag;
	}
	
	
/*	// Display all stems
	public void display() {
		
		// Formatted display
		System.out.println("GenerationSet ");
		System.out.println("------------------------------------------------------------------------------------------------------");
		bg.display(bg.getRoot());
		System.out.println("******************************************************************************************************");
	}*/
	
	
	// Complete initialization and display
	@Override
	public void run() {
		
		// initialize
		bg = new BGGeneration(number);
		br = new BGRuleDynamic(bg, radians, rule);
		
		// dynamic grow		
		while(runflag) {
			
			for (int i = 0; i < bg.getLayer() + 1; i++) {
				
				try {
						// delay
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					
					// Stop
					if (runflag == false) {
						// Stop draw
						break;
					}
					
					// Pause
					while (pauseflag) {
//						System.out.println(pauseflag);
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					
					br.setRule(rule);
					
					if (i == 0) {
						System.out.println("Rule: " + br.getRule());
						br.getStemList().add(bg.getRoot());
						System.out.println("create geneset " + br.getStemList().size());
					}
					
					else if (i == 1) {
						System.out.println("rule " + br.getRule());
						br.addChildStemDynamic(bg.getRoot());
						System.out.println("create geneset: "+ br.getStemList().size());
					}
					
					else {
//						br.setRule(3);
						System.out.println("rule " + br.getRule());
						br.growByLayerDynamic(bg.getRoot());
						System.out.println("create geneset: "+ br.getStemList().size());
					}
					
//					else if (i <= bg.getLayer() - 2) {
//						System.out.println("rule " + br.getRule());
//						br.growByLayerDynamic(bg.getRoot());
//						System.out.println("create geneset: "+ br.getStemList().size());
//					}
//					
//					else {
//						br.setRule(3);
//						System.out.println("rule " + br.getRule());
//						br.growByLayerDynamic(bg.getRoot());
//						System.out.println("create geneset: "+ br.getStemList().size());
//					}
					
//					bg.display(bg.getRoot());
					
					// Observe and pass the stemList to BGPanel
					setChanged();
					notifyObservers(br.getStemList());
			}
			
			// Complete Growth
			runflag = false;
		}
	}
	
	
	// Test
    public static void main(String[] args) throws java.io.IOException {
		// Input Instruction
		char inChar = ' ';
		System.out.println("*****Please Enter the GenerationSet Number*****");
		inChar = (char) System.in.read();
		
		// Read '\r' and '\n' and do nothing
		System.in.read();
		System.in.read();
		
		// Create instances
		BGGenerationSetDynamic bs = new BGGenerationSetDynamic(Character.getNumericValue(inChar), Math.PI/3, 3);
		
//		// Write print context to file
//		FileOutputStream bos = null;
//		// Error dealing
//		try {
//			bos = new FileOutputStream("BGGenerationSet.txt");
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//		}
//		System.setOut(new PrintStream(bos));
		
		// Dynamic Rule
		bs.run();		
	}
}