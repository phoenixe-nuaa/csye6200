/**
 * 
 */
package edu.neu.csye6200.bg;

import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Line2D;
import java.util.ArrayList;

/**Class BGRule: process input BGGenerations and produce output generations according to the layer
 * @author Chen.JL
 *
 */
public class BGRuleDynamic {
	
	// To store all the stems
	public ArrayList<BGStem> stemList = new ArrayList<>();
	
	// input generation
	private BGGeneration gene;
	
	// Control the relative angles of each child stem
	private Double radians;
	
	// number of child stems
	private Integer rule;
	
	
	// Constructor
	public BGRuleDynamic(BGGeneration gene, Double radians, Integer rule) {
		this.gene = gene;
		this.radians = radians;	
		this.rule = rule;
	}
	
	
	// Getters and Setters
	public BGGeneration getGene() {
		return gene;
	}

	
	public void setGene(BGGeneration gene) {
		this.gene = gene;
	}

	
	public Double getRadians() {
		return radians;
	}

	
	public void setRadians(Double radians) {
		this.radians = radians;
	}

	
	public ArrayList<BGStem> getStemList() {
		return stemList;
	}

	
	public void setStemList(ArrayList<BGStem> stemList) {
		this.stemList = stemList;
	}

	
	public Integer getRule() {
		return rule;
	}

	
	public void setRule(Integer number) {
		this.rule = number;
	}
	
	
	/*	public void grow() {
		stemList.add(gene.getRoot());
		
		// Root grows first
		if (gene.getLayer() >= 1)
			addChildStemCustom(gene.getRoot());
	}*/
	
/*	// store all child stems and grow root firstly
	public void growByGeneDynamic() {
		stemList.add(gene.getRoot());
		
		// Root grows first
		if (gene.getLayer() >= 1) {
			addChildStemDynamic(gene.getRoot());
		}
	}
	
	// grow by input number and layer
	public void growDynamic(Integer rule, Integer layer) {
		
		setRule(rule);
		
//		if (gene.getLayer() >= 1) {
//			addChildStemDynamic(gene.getRoot());
//		}
		
		for (int i = 0; i < layer; i++) {
			growByLayerDynamic(gene.getRoot());
		}
	}*/
	
	
	// Search the deepest stem and add child stems on them
	public void growByLayerDynamic(BGStem stem) {		
		for (BGStem stems: stem.getChildlist()) {
			if (stems.getChildlist().isEmpty())
//				addChildStemCustom(stems);
				addChildStemDynamic(stems);
			else
				growByLayerDynamic(stems);
		}
//		System.out.println("calling growByLayerDynamic method");
	}
	
	
	// Calculate the node coordinates
	public ArrayList<Double> branch(BGStem parent) {
		
		// Store the node coordinates
		ArrayList <Double> node = new ArrayList<Double>();
		
		// Calculate
		node.add(parent.getLength() * Math.cos(parent.getDirection()) + parent.getX());
		node.add(parent.getLength() * Math.sin(parent.getDirection()) + parent.getY());
		
		return node;
	}
	
	
	// add to stemList
	public void addChildStemDynamic(BGStem stem) {
		
//		setRule(rule);
		
		for (BGStem stm: rule(stem).getChildlist()) {
//			System.out.println("add child stems");
			stemList.add(stm);
		}
	}
	
	
	// Add child stems according to rule
	public BGStem rule(BGStem stem) {
		
		ArrayList <Double> node = new ArrayList<Double>();
		node = branch(stem);
		
		switch(rule) {
		
		case 1:
			
			BGStem stm1 = new BGStem(node.get(0), node.get(1), stem.getLength()*0.66, stem.getDirection() - radians, stem.getDepth() + 1);
			BGStem stm2 = new BGStem(node.get(0), node.get(1), stem.getLength()*0.66, stem.getDirection() + radians, stem.getDepth() + 1);
			
			stem.getChildlist().add(stm1);
			stem.getChildlist().add(stm2);
//			System.out.println("growing 2 child stems");
			break;
		
		case 2:
			
			BGStem stm3 = new BGStem(node.get(0), node.get(1), stem.getLength()*0.66, stem.getDirection() - radians, stem.getDepth() + 1);
			BGStem stm4= new BGStem(node.get(0), node.get(1), stem.getLength()*0.66, stem.getDirection(), stem.getDepth() + 1);
			BGStem stm5 = new BGStem(node.get(0), node.get(1), stem.getLength()*0.66, stem.getDirection() + radians, stem.getDepth() + 1);
			
			stem.getChildlist().add(stm3);
			stem.getChildlist().add(stm4);
			stem.getChildlist().add(stm5);
//			System.out.println("growing 3 child stems");
			break;
		
		case 3:
			
			BGStem stm6 = new BGStem(node.get(0), node.get(1), stem.getLength()*0.66, stem.getDirection() - radians, stem.getDepth() + 1);
			BGStem stm7 = new BGStem(node.get(0), node.get(1), stem.getLength()*0.66, stem.getDirection() - radians*2, stem.getDepth() + 1);
			BGStem stm8 = new BGStem(node.get(0), node.get(1), stem.getLength()*0.66, stem.getDirection() + radians, stem.getDepth() + 1);
			BGStem stm9 = new BGStem(node.get(0), node.get(1), stem.getLength()*0.66, stem.getDirection() + radians*2, stem.getDepth() + 1);
			
			stem.getChildlist().add(stm6);
			stem.getChildlist().add(stm7);
			stem.getChildlist().add(stm8);
			stem.getChildlist().add(stm9);
			break;
		}
		
		return stem;
	}
	
/*	// add to stemList
	public void growByLayerDynamicnew(BGStem stem) {
		
//		setRule(rule);
		
		switch (rule) {
		case 2:
			for 
		case 3:
		case 4:
		}
		for (BGStem stm: rule(stem).getChildlist()) {
//			System.out.println("add child stems");
			stemList.add(stm);
		}
	}*/
	
}
