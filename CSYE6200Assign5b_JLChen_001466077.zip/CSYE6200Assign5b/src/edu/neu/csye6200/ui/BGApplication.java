/**
 * 
 */
package edu.neu.csye6200.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowEvent;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Logger;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import edu.neu.csye6200.bg.BGGenerationSet;
import edu.neu.csye6200.bg.BGGenerationSetDynamic;

/** Class BGApplication: The application of plant growth
 *  Jframe, JPanel, button control and everything
 * @author Chen.JL
 *
 */
public class BGApplication extends BGApp{

	// log
	private static Logger log = Logger.getLogger(BGApplication.class.getName());
	
	// Panels
	protected static JPanel mainPanel = null;
	protected JPanel northPanel = null;
	protected static BGPanel bgPanel;
	
	// Control Buttons
	protected JButton startBtn;
	protected JButton pauseresumeBtn;
	protected JButton stopBtn;
	protected JButton clearBtn;
	
	// Custom Rule or Dynamic Rule
	protected JRadioButton dynamicRule;
	protected JRadioButton customRule;
	
	// To Apply a new rule
	protected JButton newruleBtn;
	
	// Current Rule
	protected Integer currentRule;
	
	// Rule Selection
	protected JLabel rl;
	protected JComboBox<String> rule;
	
	// Input number of generations
    protected JLabel gn;
	protected JTextField geneNum;
	
	// number of generations
	protected Integer num;
	
	// geneSet
	protected BGGenerationSet bs;
	protected BGGenerationSetDynamic bsd;
	
	// Constructor
    public BGApplication() {
    	
    	frame.setSize(1100, 1000);
    	frame.setTitle("BGApplication");
//    	menuMgr.createDefaultActions();
    	showUI();
    }
    
    
    // mainPanel
    @Override
    public JPanel getMainPanel() {
    	
    	mainPanel = new JPanel();
    	mainPanel.setLayout(new BorderLayout());
    	mainPanel.add(BorderLayout.NORTH, getNorthPanel());
    	
    	bgPanel = new BGPanel();
    	mainPanel.add(BorderLayout.CENTER, bgPanel);

    	return mainPanel;
    }

	
    // draw every generations on bgPanel
    public void startSim(Integer rule) {
    	
    	// start after entering the number of generations and choosing a rule
//		bs.setRunflag(true);
    	num = Integer.valueOf(geneNum.getText());
    	bsd = new BGGenerationSetDynamic(num, Math.PI/6, rule);
		bsd.setRunflag(true);
		
		// start thread
//    	Thread t = new Thread(bs);
    	Thread t = new Thread(bsd);
    	t.start();
    	
    	// observe
//    	bs.addObserver(bgPanel);
    	bsd.addObserver(bgPanel);
    	System.out.println("start sim");
    }
    
    
//    // initialization
//    public void initiBS() {
//    	String s = geneNum.getText();
//    	num = Integer.parseInt(s);
//    }
    
    
/*    // refresh panel
    private void startPanelTimerTask() {
    	Timer timer = new Timer();
    	timer.scheduleAtFixedRate(new TimerTask() {
    		
    		public void run() {
    			bgPanel.repaint();
    		}
    	}, 0, 1000);
    }*/
    
	
    public static void refresh() {
//    	System.out.println("refresh");
    	bgPanel.repaint();
    }
    
    
    // Control Panel
	public JPanel getNorthPanel() {
    	
		northPanel = new JPanel();
    	northPanel.setLayout(new FlowLayout());
    	
    	customRule = new JRadioButton("Custom Rule");
    	dynamicRule = new JRadioButton("Dynamic Rule");
    	
    	ButtonGroup group = new ButtonGroup();
    	group.add(customRule);
    	group.add(dynamicRule);

    	northPanel.add(customRule);
    	northPanel.add(dynamicRule);
    	
    	customRule.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				newruleBtn.setEnabled(false);
			}
    	});
    	
    	dynamicRule.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				// TODO Auto-generated method stub
				newruleBtn.setEnabled(true);
			}
    	});
    	
    	// Add components
    	gn = new JLabel("Please enter the number of Generations");
    	northPanel.add(gn);
    	
    	geneNum = new JTextField(3);
    	northPanel.add(geneNum);
    	
    	rl = new JLabel("Please select a rule:");
    	northPanel.add(rl);
    	
    	rule = new JComboBox<String>();
    	northPanel.add(rule);
    	rule.addItem("...");
    	rule.addItem("Rule 1");
    	rule.addItem("Rule 2");
    	rule.addItem("Rule 3");
    	
    	rule.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				
				if (e.getStateChange() == ItemEvent.SELECTED) {
					
					switch((String)(e.getItem())) {
					case "Rule 1": {
						currentRule = 1;
						System.out.println("Chossing rule 1");
						break;
					}
					
					case "Rule 2": {
						currentRule = 2;
						System.out.println("Chossing rule 2");
						break;
					}
					
					case "Rule 3": {
						currentRule = 3;
						System.out.println("Chossing rule 3");
						break;
					}
					}
				}
			}
    		
    	});
    	
    	newruleBtn = new JButton("Apply a new rule");
    	northPanel.add(newruleBtn);
    	
    	newruleBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				bsd.setRule(currentRule);
			}
    		
    	});
    	
//    	geneNum.addActionListener(new java.awt.event.ActionListener() {
//			
//    		@Override
//			public void actionPerformed(ActionEvent e) {
//				String s = geneNum.getText();
//				System.out.println("Number of Generations"+ s);
//				num = Integer.valueOf(s);
//    		}
//    	
//    	});
    	
    	startBtn = new JButton("Start");
    	// Allow the application to hear about button pushes
    	startBtn.addActionListener(this); 
    	northPanel.add(startBtn);
    	
    	pauseresumeBtn = new JButton("Pause/Resume");
    	pauseresumeBtn.addActionListener(this);
    	northPanel.add(pauseresumeBtn);
    	
    	stopBtn = new JButton("Stop");
    	stopBtn.addActionListener(this);
    	northPanel.add(stopBtn);
    	
/*    	clearBtn = new JButton("Clear");
    	clearBtn.addActionListener(this);
    	northPanel.add(clearBtn);*/
    	
    	return northPanel;
    }

	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		log.info("We received an ActionEvent " + e);
		
		if (e.getSource() == startBtn) {
			
			System.out.println("Start pressed");
			startSim(currentRule);
			
			bgPanel.setClear(false);
			
			startBtn.setEnabled(false);
			stopBtn.setEnabled(true);
			pauseresumeBtn.setEnabled(true);
		}
		
		if (e.getSource() == pauseresumeBtn) {
			System.out.println("Pause/Resume pressed");
//			bs.invert();
			bsd.invert();
			
/*			if (bs.isPauseflag() == true) {
				bs.setPauseflag(false);
			} else {
				bs.setPauseflag(true);
			}*/			
		}
		
		if (e.getSource() == stopBtn) {
			System.out.println("Stop pressed");
			
			// stop
//			bs.setRunflag(false);
			bsd.setRunflag(false);
			
			// enable buttons
			startBtn.setEnabled(true);
			stopBtn.setEnabled(false);
			pauseresumeBtn.setEnabled(false);
			
			// reset
			geneNum.setText("");
			rule.setSelectedIndex(0);
			
			// clear
			bgPanel.setClear(true);
			refresh();
		}
		
		/*if (e.getSource() == clearBtn) {
			System.out.println("Clear pressed");
			
			bgPanel.setClear(true);
			refresh();
			
			clearBtn.setEnabled(false);
		}*/
	}

	
	@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
	}

	
	@Override
	public void windowClosed(WindowEvent arg0) {
		// TODO Auto-generated method stub
	}

	
	@Override
	public void windowClosing(WindowEvent arg0) {
		// TODO Auto-generated method stub
	}

	
	@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
	}

	
	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
	}

	
	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
	}

	
	@Override
	public void windowOpened(WindowEvent arg0) {
		// TODO Auto-generated method stub
	}

	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		BGApplication ba = new BGApplication();
		log.info("BGApplication Started");
	}
}

/**
*on-time 5
*early finish 5
*code 20
*abstract 5 
*sim 20
*growth 15
*multi-rule 10 
*start/stop 5
*ui quality 10
*thread/comms 15
*visual quality 10
*bonus 10
*120
*/
