package edu.neu.csye6200.ui;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
import java.util.logging.Logger;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Line2D;

import javax.swing.JPanel;

import edu.neu.csye6200.bg.BGStem;

/**
 * Class BGPanel: The growth paint of each generation
 * @author JL.Chen
 */
public class BGPanel extends JPanel implements Observer{

	private static final long serialVersionUID = 1L;
	private Logger log = Logger.getLogger(BGPanel.class.getName());
    private int lineSize = 20;
    private Color col = null;
    private long counter = 0L;
    private boolean clear = false;
    // rule set
    
    public ArrayList<BGStem> stemList;
    
    
    public boolean isClear() {
		return clear;
	}


	public void setClear(boolean clear) {
		this.clear = clear;
	}


	public ArrayList<BGStem> getStemList() {
		return stemList;
	}


	public void setStemList(ArrayList<BGStem> stemList) {
		this.stemList = stemList;
	}


	/**
     * Canvas constructor
     */
	public BGPanel() {

		this.col = Color.WHITE;
		this.stemList = new ArrayList<BGStem>();
		this.setBackground(Color.BLACK);
	}
	
	
	/**
	 * The UI thread calls this method when the screen changes, or in response
	 * to a user initiated call to repaint();
	 */
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		
		// Our Added-on drawing
		if (!clear) {
			draw(g);
			drawBG(g);
			System.out.println("calling paint method");
		}
		else {
			draw(g);			
		}
    }
	
	
	/**
	 * Draw the stems on bgPanel
	 * @param g
	 */
	
	// 	background setting
	public void draw(Graphics g) {
		
		Graphics2D g2d = (Graphics2D) g;
		Dimension size = getSize();
		
		g2d.setColor(Color.BLACK);
		g2d.fillRect(0, 0, size.width, size.height);
		
		g2d.setColor(Color.RED);
		g2d.setFont(new Font("Times Roman", Font.BOLD, 20));
		g2d.drawString("BG Visualization", 10, 30);
		g2d.drawString("by Jialin Chen", 10, 60);
		
//		System.out.println("Clear");
	}
	
	
	// draw each generation of BGGenerationSet
	public void drawBG(Graphics g) {
		
		log.info("Drawing BG " + counter++);
		Graphics2D g2 = (Graphics2D) g;
		
		// Set the origin 
		g2.translate(550, 900);
		
/*		Dimension size = getSize();
		int maxRows = size.height / lineSize;
		int maxCols = size.width / lineSize;
		for (int j = 0; j < maxRows; j++) {
		   for (int i = 0; i < maxCols; i++) {
			   int redVal = validColor(i*5);
			   int greenVal = validColor(255-j*5);
			   int blueVal = validColor((j*5)-(i*2));
			   col = new Color(redVal, greenVal, blueVal);
		   }
		}*/
		
		// Paint
		if (stemList == null) {
			System.out.println("stemList is null");
			return;
		} 
		else {
			
			if (stemList.size() == 0) System.out.println(stemList.size());
			else g2.drawString(String.valueOf("This is Generation: " + stemList.get(stemList.size()-1).getDepth()), 300, 0);
			
			System.out.println("stemList is not null");
			
			// Flip
			g2.scale(1, -1);
			
			// Draw Stems according to coordinates
			for (BGStem stm: stemList) {
//				if(stemList.indexOf(stm) < 13) {
//					g2.setColor(Color.GREEN);
//					paintLine(g2, stm);
//				}
//				else {
//					g2.setColor(Color.WHITE);
//					paintLine(g2, stm);
//				}
				paintLine(g2, stm);
//				paintLine(g2, stm, col);
			}
		}
	}

/*	private int validColor(int colorVal) {
		if (colorVal > 255)
			colorVal = 255;
		if (colorVal < 0)
			colorVal = 0;
		return colorVal;
	}*/

	/**
	 * A convenience routine to set the color and draw a line
	 * @param g2d the 2D Graphics context
	 * @param startx the line start position on the x-Axis
	 * @param starty the line start position on the y-Axis
	 * @param endx the line end position on the x-Axis
	 * @param endy the line end position on the y-Axis
	 * @param color the line color
	 */
	private void paintLine(Graphics2D g2, BGStem stm) {
		
		double x1 = stm.getX();
		double x2 = stm.getLength() * Math.cos(stm.getDirection()) + stm.getX();
		double y1 = stm.getY();
		double y2 = stm.getLength() * Math.sin(stm.getDirection()) + stm.getY();
		
		Line2D line = new Line2D.Double(x1, y1, x2, y2);
		
		// Set stroke
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setStroke(new BasicStroke((float) (0.15f * stm.getLength())));
		g2.setColor(Color.WHITE);
		
		// Draw line
		g2.draw(line);
	}

	
	@Override
	public void update(Observable bs, Object stemlist) {
		// Refresh based on Observation
			stemList = (ArrayList<BGStem>) stemlist;
			System.out.println("update " + stemList.size());
//			this.repaint();
			BGApplication.refresh();
	}	
}
