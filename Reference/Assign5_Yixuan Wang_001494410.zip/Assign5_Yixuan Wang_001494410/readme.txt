## CSYE-6200-Assignment 5ab
#### Yixuan Wang
#### NUID��001494410

---

**File Description:**

- src: the Source file of this program.
- screenShot_BGAPP: the file to store screenshot pictures when you click the 'Screenshot' item in the menubar 'File'.
- BGDemo.gif: A demo to show how to use this APP.
				   

---

**Introduction:**

If you wish, it is better to check the BGDemo.gif at first(only about 20s).
Please check all detailed information by clicking the button 'Help' or menubar 'Help' at first.
You can run my program in the WolfApp class file.

Thank you for checking my Assignment 5ab.