package edu.neu.csye6200.ui;

public enum RuleSet {
	RULE1, RULE2, RULE3, NULL

}
